Visualizar Planeamento
---------------------------------------------------------------------

1- Preparar Dados
	- Exportar do programa para ficheiro com nome dados.csv
	- Formato dos dados a exportar:
		- Quatro colunas
			- maquina Id
			- Descrição
			- Inicio
			- Diracao
			
			Exemplo:
			maquina 1,job 1 - Oper 2, 5, 12

2- Copiar todos os ficheiros, incluindo o "dados.csv" para uma pasta

3- Instalar e executar um Servidor Web
	Sugestão: https://www.jetbrains.com/webstorm/

4- Abrir o ficheiro Plan.html a partir do IDE 

lufer
EDA-2022