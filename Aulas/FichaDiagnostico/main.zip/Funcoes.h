/*
* author: lufer
* email: lufer@ipca.pt
* date: 27.02.2022
* desc: Assinaturas e Dados Globais
*/

///@Funcoes.h

//#pragma once
//ou

#include <stdio.h>

#ifndef FUNC
#pragma warning(disable : 4996)		//ignorar avisos 4996

#pragma region Globais

/**
* Total de Objetos
*/
#define N 40
/**
* N�mero de caracteres de um nome
*/
#define MAXNOME 40	

typedef enum { F, T } bool;	///Boolean

/**
 * The enumeration of space dimension
 */
typedef enum
{
  UND,    /**< 1D */
  DEUXD,  /**< 2D */
  TROISD  /**< 3D */
} dimensions;

/**
* Defini��o de um Objeto
*/
typedef struct Objeto {
	/*@{*/
	char nome[MAXNOME];	/**< Designa��o do Objeto*/
	float dist;			/**< Distancia do objeto */
	/*@}*/
}Objeto;

/**
* Estrutura de dados com todos os objetos da Ficha de Diagn�stico
*/
extern Objeto objetos[N];				//extern: vari�vel definida algures

#pragma endregion

#pragma region Assinaturas

double MediaArray(double v[], int n);

//a)
float MediaDistanciaObjetos(Objeto v[], int n);

//c
Objeto QualMaisLonge(Objeto v[], int n);

//f
bool GravaDados(char*nomeFicheiro, Objeto v[], int n);

//Ler Dados do ficheiro
long LeDados(char* nomeFicheiro, Objeto v[]);

#pragma endregion

#define FUNC
#endif

